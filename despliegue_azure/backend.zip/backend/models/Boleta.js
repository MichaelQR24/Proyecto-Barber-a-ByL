// archivo: models/Boleta.js
// Este modelo fue eliminado ya que las consultas se hacen directamente en el controlador
// para mantener consistencia con el patrón usado en otros controladores como reservaController.js